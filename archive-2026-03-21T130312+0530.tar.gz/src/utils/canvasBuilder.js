'use strict';

const { createCanvas, loadImage } = require('@napi-rs/canvas');
const axios = require('axios');
const { filterContent } = require('./mentionFilter');

const W = 900;
const H = 280;

const ACCENT   = '#e94560';
const BG       = '#0f0f13';
const SURFACE  = '#17171d';
const TEXT_PRI = '#ffffff';
const TEXT_SEC = 'rgba(255,255,255,0.45)';
const TRACK_BG = 'rgba(255,255,255,0.08)';

const SOURCE_COLORS = {
  youtube:    '#FF0000',
  soundcloud: '#FF5500',
  spotify:    '#1DB954',
  deezer:     '#FEAA2D',
  applemusic: '#FC3C44',
  http:       '#7289DA'
};

const truncate = (str, len) => {
  if (!str) return '';
  const s = filterContent(str);
  return s.length > len ? s.slice(0, len - 1) + '…' : s;
};

const formatTime = (ms) => {
  if (!ms || ms < 0) return '0:00';
  const s = Math.floor(ms / 1000);
  const m = Math.floor(s / 60);
  return `${m}:${String(s % 60).padStart(2, '0')}`;
};

const roundRect = (ctx, x, y, w, h, r) => {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
};

const fetchImage = async (url) => {
  try {
    const res = await axios.get(url, { responseType: 'arraybuffer', timeout: 5000 });
    return await loadImage(Buffer.from(res.data));
  } catch (_) {
    return null;
  }
};

// ── Now Playing Card ──────────────────────────────────────────────────────────

const buildNowPlayingCard = async (track, player, requester) => {
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');

  const thumbImg = track.info.artworkUrl ? await fetchImage(track.info.artworkUrl) : null;

  // Background
  ctx.fillStyle = BG;
  ctx.fillRect(0, 0, W, H);

  // Blurred backdrop — very dark
  if (thumbImg) {
    ctx.save();
    ctx.filter = 'blur(40px) brightness(0.12) saturate(1.2)';
    ctx.drawImage(thumbImg, -60, -60, W + 120, H + 120);
    ctx.restore();
  }

  // Left accent bar
  ctx.fillStyle = ACCENT;
  ctx.fillRect(0, 0, 3, H);

  // Artwork
  const ART_X = 30, ART_Y = 28, ART_S = 224, ART_R = 12;

  if (thumbImg) {
    ctx.save();
    roundRect(ctx, ART_X, ART_Y, ART_S, ART_S, ART_R);
    ctx.clip();
    ctx.drawImage(thumbImg, ART_X, ART_Y, ART_S, ART_S);
    ctx.restore();
    ctx.save();
    roundRect(ctx, ART_X, ART_Y, ART_S, ART_S, ART_R);
    ctx.strokeStyle = 'rgba(255,255,255,0.07)';
    ctx.lineWidth = 1;
    ctx.stroke();
    ctx.restore();
  } else {
    ctx.save();
    roundRect(ctx, ART_X, ART_Y, ART_S, ART_S, ART_R);
    ctx.fillStyle = SURFACE;
    ctx.fill();
    ctx.fillStyle = 'rgba(233,69,96,0.3)';
    ctx.font = 'bold 64px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('♪', ART_X + ART_S / 2, ART_Y + ART_S / 2 + 22);
    ctx.textAlign = 'left';
    ctx.restore();
  }

  // Source badge
  const sourceName = track.info.sourceName || 'youtube';
  const sourceLabel = sourceName.charAt(0).toUpperCase() + sourceName.slice(1);
  const badgeColor = SOURCE_COLORS[sourceName] || SOURCE_COLORS.http;

  ctx.save();
  ctx.font = 'bold 11px sans-serif';
  const bW = ctx.measureText(sourceLabel).width + 16;
  const bH = 20;
  const bX = ART_X + ART_S - bW - 8;
  const bY = ART_Y + 8;
  roundRect(ctx, bX, bY, bW, bH, 5);
  ctx.fillStyle = badgeColor;
  ctx.fill();
  ctx.fillStyle = '#ffffff';
  ctx.fillText(sourceLabel, bX + 8, bY + 14);
  ctx.restore();

  // Right panel
  const PX = ART_X + ART_S + 30;
  const PW = W - PX - 28;

  // Title
  ctx.fillStyle = TEXT_PRI;
  ctx.font = 'bold 28px sans-serif';
  ctx.fillText(truncate(track.info.title, 32), PX, 66);

  // Artist
  ctx.fillStyle = TEXT_SEC;
  ctx.font = '16px sans-serif';
  ctx.fillText(truncate(track.info.author, 44), PX, 94);

  // Progress bar
  const BAR_Y = 124;
  const BAR_H = 4;
  const progress = player.position || 0;
  const duration = track.info.length || 1;
  const ratio = Math.min(progress / duration, 1);

  roundRect(ctx, PX, BAR_Y, PW, BAR_H, 2);
  ctx.fillStyle = TRACK_BG;
  ctx.fill();

  if (ratio > 0) {
    const fillW = Math.max(PW * ratio, BAR_H);
    roundRect(ctx, PX, BAR_Y, fillW, BAR_H, 2);
    ctx.fillStyle = ACCENT;
    ctx.fill();
  }

  // Time labels
  ctx.fillStyle = TEXT_SEC;
  ctx.font = '12px sans-serif';
  ctx.textAlign = 'left';
  ctx.fillText(formatTime(progress), PX, BAR_Y + 20);
  ctx.textAlign = 'right';
  ctx.fillText(formatTime(duration), PX + PW, BAR_Y + 20);
  ctx.textAlign = 'left';

  // Status pills
  let pillX = PX;
  const PILL_Y = 168;
  const PILL_H = 24;

  const drawPill = (label, bg) => {
    ctx.save();
    ctx.font = 'bold 11px sans-serif';
    const tw = ctx.measureText(label).width;
    const pw = tw + 18;
    roundRect(ctx, pillX, PILL_Y, pw, PILL_H, 4);
    ctx.fillStyle = bg;
    ctx.fill();
    ctx.fillStyle = TEXT_PRI;
    ctx.fillText(label, pillX + 9, PILL_Y + 16);
    ctx.restore();
    pillX += pw + 8;
  };

  if (player.loopMode && player.loopMode !== 'off') {
    drawPill(`↻ ${player.loopMode.toUpperCase()}`, '#2a2a3a');
  }

  drawPill(`VOL ${player.volume ?? 50}%`, '#1e2a1e');

  if (player.paused) {
    drawPill('PAUSED', '#2a2020');
  }

  // Requester
  if (requester) {
    const name = truncate(requester.displayName || requester.username || 'Unknown', 24);
    const AVS = 26;
    const REQ_Y = H - 36;

    const avatarUrl = requester.displayAvatarURL?.({ extension: 'png', size: 64 });
    if (avatarUrl) {
      const avatarImg = await fetchImage(avatarUrl);
      if (avatarImg) {
        ctx.save();
        ctx.beginPath();
        ctx.arc(PX + AVS / 2, REQ_Y + AVS / 2, AVS / 2, 0, Math.PI * 2);
        ctx.clip();
        ctx.drawImage(avatarImg, PX, REQ_Y, AVS, AVS);
        ctx.restore();
      }
    }

    ctx.fillStyle = TEXT_SEC;
    ctx.font = '12px sans-serif';
    ctx.fillText(`Requested by ${name}`, PX + AVS + 8, REQ_Y + 17);
  }

  return canvas.toBuffer('image/png');
};

// ── Help Banner ───────────────────────────────────────────────────────────────

const buildHelpBanner = async () => {
  const BW = 900, BH = 220;
  const canvas = createCanvas(BW, BH);
  const ctx = canvas.getContext('2d');

  ctx.fillStyle = BG;
  ctx.fillRect(0, 0, BW, BH);

  // Subtle dark surface band
  ctx.fillStyle = SURFACE;
  ctx.fillRect(0, BH - 60, BW, 60);

  // Left accent bar
  ctx.fillStyle = ACCENT;
  ctx.fillRect(0, 0, 3, BH);

  // Thin top rule
  ctx.fillStyle = ACCENT;
  ctx.fillRect(0, 0, BW, 1);

  // Waveform bars
  const BAR_COUNT = 48;
  const BAR_W = 4;
  const GAP = 13;
  const TOTAL = BAR_COUNT * (BAR_W + GAP);
  const startX = (BW - TOTAL) / 2;

  for (let i = 0; i < BAR_COUNT; i++) {
    const x = startX + i * (BAR_W + GAP);
    const h = 10 + (Math.sin(i * 0.45 + 1.2) * 0.5 + 0.5) * 48 + Math.sin(i * 0.9) * 14;
    const alpha = 0.12 + (i / BAR_COUNT) * 0.1;
    roundRect(ctx, x, BH - h, BAR_W, h, 2);
    ctx.fillStyle = `rgba(233,69,96,${alpha})`;
    ctx.fill();
  }

  // Title
  ctx.fillStyle = TEXT_PRI;
  ctx.font = 'bold 50px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('TITAN MUSIC', BW / 2, 82);

  // Underline
  ctx.fillStyle = ACCENT;
  ctx.fillRect(BW / 2 - 80, 92, 160, 2);

  // Subtitle
  ctx.fillStyle = TEXT_SEC;
  ctx.font = '14px sans-serif';
  ctx.fillText('Premium Music Experience  ·  v2.0.0', BW / 2, 120);

  // Command hints
  ctx.fillStyle = 'rgba(255,255,255,0.22)';
  ctx.font = '12px sans-serif';
  ctx.fillText('/play  ·  /queue  ·  /filters  ·  /lyrics  ·  and more', BW / 2, 142);

  // Separator
  ctx.fillStyle = 'rgba(255,255,255,0.06)';
  ctx.fillRect(60, 156, BW - 120, 1);

  ctx.textAlign = 'left';

  return canvas.toBuffer('image/png');
};

module.exports = { buildNowPlayingCard, buildHelpBanner };
