'use strict';

const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

const buildControlPanel = (player) => {
  const isPaused = player?.shoukakuPlayer?.paused;
  const isLooping = player?.loopMode && player.loopMode !== 'off';

  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('previous_track')
      .setEmoji('⏮')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('play_pause')
      .setEmoji(isPaused ? '▶' : '⏸')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId('stop_player')
      .setEmoji('⏹')
      .setStyle(ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId('loop_toggle')
      .setEmoji('🔁')
      .setStyle(isLooping ? ButtonStyle.Success : ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('shuffle_queue')
      .setEmoji('🔀')
      .setStyle(ButtonStyle.Secondary)
  );
};

module.exports = { buildControlPanel };
