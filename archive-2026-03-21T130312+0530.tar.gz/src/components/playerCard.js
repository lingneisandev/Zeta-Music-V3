'use strict';

const {
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  MediaGalleryBuilder,
  MediaGalleryItemBuilder,
  SeparatorSpacingSize,
  MessageFlags,
  AttachmentBuilder
} = require('discord.js');
const { buildNowPlayingCard } = require('../utils/canvasBuilder');
const { buildControlPanel } = require('./controlPanel');
const { formatDuration, COLORS } = require('../utils/embedBuilder');
const { filterContent } = require('../utils/mentionFilter');

const NO_PING = { allowedMentions: { parse: [] } };

const buildPlayerCard = async (track, player, requester) => {
  const buffer = await buildNowPlayingCard(track, player, requester);
  const attachment = new AttachmentBuilder(buffer, { name: 'nowplaying.png' });

  const title = filterContent(track.info.title);
  const author = filterContent(track.info.author);
  const requesterName = filterContent(requester?.displayName || requester?.username || 'Unknown');
  const source = (track.info.sourceName || 'youtube');
  const sourceName = source.charAt(0).toUpperCase() + source.slice(1);
  const position = formatDuration(player.position || 0);
  const duration = formatDuration(track.info.length);

  const statusParts = [
    player.loopMode !== 'off' ? `\`${player.loopMode.toUpperCase()}\`` : null,
    `\`Vol ${player.volume ?? 50}%\``,
    player.paused ? `\`PAUSED\`` : null
  ].filter(Boolean).join('  ');

  const container = new ContainerBuilder()
    .setAccentColor(COLORS.music);

  container.addMediaGalleryComponents(
    new MediaGalleryBuilder().addItems(
      new MediaGalleryItemBuilder().setURL('attachment://nowplaying.png')
    )
  );

  container.addSeparatorComponents(
    new SeparatorBuilder().setDivider(false).setSpacing(SeparatorSpacingSize.Small)
  );

  container.addTextDisplayComponents(
    new TextDisplayBuilder().setContent(
      `### ${title}\n` +
      `**${author}**\n` +
      `\`${position} / ${duration}\`  ${statusParts}\n` +
      `${sourceName}  ·  ${requesterName}`
    )
  );

  container.addSeparatorComponents(
    new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
  );

  container.addActionRowComponents(buildControlPanel(player));

  return {
    files: [attachment],
    components: [container],
    flags: MessageFlags.IsComponentsV2,
    ...NO_PING
  };
};

const deletePlayerCard = async (message) => {
  if (!message) return;
  try {
    await message.delete();
  } catch {
    // Message already deleted or missing permissions
  }
};

module.exports = { buildPlayerCard, deletePlayerCard };
