'use strict';

const { log } = require('../utils/logger');
const E = require('../emoji');
const { buildPlayerCard } = require('../components/playerCard');
const { musicContainer, errorContainer, v2 } = require('../utils/embedBuilder');
const playerManager = require('../lavalink/playerManager');
const { sleep } = require('../utils/logger');

const NO_PING = { allowedMentions: { parse: [] } };

const setupPlayerEvents = (client, playerData) => {
  const { shoukakuPlayer, guildId } = playerData;

  shoukakuPlayer.on('start', async () => {
    log.music(`${E.play} [EVENT:START] Track successfully started in guild ${guildId}`);
    const player = playerManager.getPlayer(client, guildId);
    if (!player || !player.current) return;

    try {
      await shoukakuPlayer.setGlobalVolume(player.volume ?? 50);
    } catch (_) { }

    try {
      const channel = await client.channels.fetch(player.textChannelId);
      if (!channel) return;

      const requester = player.current.requester || null;
      const cardMessage = await buildPlayerCard(player.current, player, requester);
      await channel.send({ ...cardMessage, ...NO_PING });
    } catch (err) {
      log.error(`Failed to send now-playing card: ${err.message}`);
    }
  });

  shoukakuPlayer.on('end', async (data) => {
    log.music(`${E.stop} [EVENT:END] Track ended in guild ${guildId}. Reason: ${data.reason}`);
    const player = playerManager.getPlayer(client, guildId);
    if (!player) return;

    if (data.reason === 'replaced') return;

    if (data.reason === 'loadFailed' || data.reason === 'cleanup') {
      log.music(`${E.warn} Track failed/cleaned in guild ${guildId}`);
    }

    if (player.loopMode === 'track' && player.current) {
      shoukakuPlayer.playTrack({ track: { encoded: player.current.encoded } });
      return;
    }

    if (player.loopMode === 'queue' && player.current) {
      player.queue.push(player.current);
    }

    if (player.queue.length > 0) {
      player.current = player.queue.shift();
      player.position = 0;
      shoukakuPlayer.playTrack({ track: { encoded: player.current.encoded } });
      return;
    }

    if (player.autoplay && player.current) {
      try {
        const nodeManager = require('../lavalink/nodeManager');
        const shoukaku = nodeManager.getShoukaku();
        const node = shoukaku.nodes.values().next().value;
        if (node) {
          const identifier = `ytsearch:${player.current.info.title} ${player.current.info.author}`;
          const result = await node.rest.resolve(identifier);
          if (result && result.data && Array.isArray(result.data) && result.data.length > 1) {
            const nextTrack = result.data[1];
            nextTrack.requester = client.user;
            player.current = nextTrack;
            player.position = 0;
            shoukakuPlayer.playTrack({ track: { encoded: nextTrack.encoded } });
            return;
          }
        }
      } catch (err) {
        log.error(`Autoplay failed: ${err.message}`);
      }
    }

    log.music(`${E.queue} Queue ended in guild ${guildId}`);
    player.current = null;

    try {
      const channel = await client.channels.fetch(player.textChannelId);
      if (channel) {
        await channel.send({
          ...v2(musicContainer(`${E.stop} Queue Ended`, 'No more tracks in the queue. Disconnecting in 30 seconds...')),
          ...NO_PING
        });
      }
    } catch (_) { }

    await sleep(30000);

    const stillActive = playerManager.getPlayer(client, guildId);
    if (stillActive && !stillActive.current && stillActive.queue.length === 0) {
      await playerManager.destroyPlayer(client, guildId);
    }
  });

  shoukakuPlayer.on('stuck', async (data) => {
    log.music(`${E.warn} [EVENT:STUCK] Track stuck in guild ${guildId} at threshold ${data.thresholdMs}ms`);
    const player = playerManager.getPlayer(client, guildId);
    if (!player) return;

    try {
      const channel = await client.channels.fetch(player.textChannelId);
      if (channel) {
        await channel.send({
          ...v2(errorContainer(`${E.warn} Track got stuck, skipping...`)),
          ...NO_PING
        });
      }
    } catch (_) { }

    if (player.queue.length > 0) {
      player.current = player.queue.shift();
      player.position = 0;
      shoukakuPlayer.playTrack({ track: { encoded: player.current.encoded } });
    } else {
      player.current = null;
      await playerManager.destroyPlayer(client, guildId);
    }
  });

  shoukakuPlayer.on('exception', (data) => {
    log.crash(`${E.error} [EVENT:EXCEPTION] Lavalink error in guild ${guildId}: ${data.exception?.message ?? 'Unknown error'}`);
  });

  shoukakuPlayer.on('closed', async (data) => {
    log.warn(`${E.warn} [EVENT:CLOSED] WebSocket closed for guild ${guildId} (Code: ${data.code}, Reason: ${data.reason})`);
    if (data.code === 4014) {
      log.warn(`[VOICE] Bot permission loss or server moved the bot. Destroying player...`);
      await playerManager.destroyPlayer(client, guildId);
    }
  });

  shoukakuPlayer.on('update', (data) => {
    const player = playerManager.getPlayer(client, guildId);
    if (player && data.state) {
      player.position = data.state.position || 0;
    }
  });
};

module.exports = { setupPlayerEvents };