'use strict';

const { MessageFlags } = require('discord.js');
const { handleHybrid } = require('../handlers/hybridHandler');
const { log } = require('../utils/logger');
const { errorContainer, v2, musicContainer, successContainer } = require('../utils/embedBuilder');
const { buildPlayerCard } = require('../components/playerCard');
const playerManager = require('../lavalink/playerManager');
const helpCommand = require('../commands/info/help');
const E = require('../emoji');

const NO_PING = { allowedMentions: { parse: [] } };

module.exports = {
  name: 'interactionCreate',
  once: false,
  execute: async (client, interaction) => {
    if (interaction.isChatInputCommand()) {
      const ctx = {
        type: 'slash',
        commandName: interaction.commandName,
        args: [],
        member: interaction.member,
        guild: interaction.guild,
        channel: interaction.channel,
        user: interaction.user,
        client,
        isInteraction: true,
        raw: interaction,
        replied: false,
        deferred: false,
        reply: async (options) => {
          if (typeof options === 'string') options = { content: options };
          const payload = { ...options, ...NO_PING };
          if (interaction.replied || interaction.deferred) {
            return await interaction.followUp(payload);
          }
          ctx.replied = true;
          return await interaction.reply(payload);
        },
        followUp: async (options) => {
          if (typeof options === 'string') options = { content: options };
          return await interaction.followUp({ ...options, ...NO_PING });
        },
        deferReply: async (options) => {
          ctx.deferred = true;
          return await interaction.deferReply(options);
        }
      };

      const options = interaction.options;
      if (options) {
        ctx.args = [];
        for (const opt of options.data || []) {
          ctx.args.push(opt.value);
        }
        ctx.options = options;
      }

      await handleHybrid(ctx);
      return;
    }

    if (interaction.isButton()) {
      const player = playerManager.getPlayer(client, interaction.guild?.id);
      const customId = interaction.customId;

      if (customId === 'play_pause') {
        if (!player || !player.current) {
          return await interaction.reply({ ...v2(errorContainer('No music is playing.')), ...NO_PING, ephemeral: true });
        }
        const paused = player.shoukakuPlayer.paused;
        await player.shoukakuPlayer.setPaused(!paused);
        await interaction.reply({
          ...v2(musicContainer(paused ? `${E.resume} Resumed` : `${E.pause} Paused`, paused ? 'Playback resumed.' : 'Playback paused.')),
          ...NO_PING,
          ephemeral: true
        });
        return;
      }

      if (customId === 'skip_track') {
        if (!player || !player.current) {
          return await interaction.reply({ ...v2(errorContainer('No music is playing.')), ...NO_PING, ephemeral: true });
        }
        const skipped = player.current.info.title;
        await player.shoukakuPlayer.stopTrack();
        await interaction.reply({
          ...v2(successContainer(`${E.skip} Skipped **${skipped}**`)),
          ...NO_PING,
          ephemeral: true
        });
        return;
      }

      if (customId === 'stop_player') {
        if (!player) {
          return await interaction.reply({ ...v2(errorContainer('No music is playing.')), ...NO_PING, ephemeral: true });
        }
        await playerManager.destroyPlayer(client, interaction.guild.id);
        await interaction.reply({
          ...v2(successContainer(`${E.stop} Player stopped and disconnected.`)),
          ...NO_PING,
          ephemeral: true
        });
        return;
      }

      if (customId === 'loop_toggle') {
        if (!player || !player.current) {
          return await interaction.reply({ ...v2(errorContainer('No music is playing.')), ...NO_PING, ephemeral: true });
        }
        const modes = ['off', 'track', 'queue'];
        const currentIndex = modes.indexOf(player.loopMode);
        player.loopMode = modes[(currentIndex + 1) % modes.length];
        await interaction.reply({
          ...v2(musicContainer(`${E.loop} Loop Mode`, `Loop set to: **${player.loopMode}**`)),
          ...NO_PING,
          ephemeral: true
        });
        return;
      }

      if (customId === 'shuffle_queue') {
        if (!player || player.queue.length < 2) {
          return await interaction.reply({ ...v2(errorContainer('Not enough tracks to shuffle.')), ...NO_PING, ephemeral: true });
        }
        for (let i = player.queue.length - 1; i > 0; i--) {
          const j = Math.floor(Math.random() * (i + 1));
          [player.queue[i], player.queue[j]] = [player.queue[j], player.queue[i]];
        }
        await interaction.reply({
          ...v2(successContainer(`${E.shuffle} Shuffled ${player.queue.length} tracks.`)),
          ...NO_PING,
          ephemeral: true
        });
        return;
      }

      if (customId === 'previous_track') {
        await interaction.reply({
          ...v2(musicContainer(`${E.info} Previous`, 'Previous track is not available in this session.')),
          ...NO_PING,
          ephemeral: true
        });
        return;
      }

      if (customId === 'queue_prev' || customId === 'queue_next') {
        await interaction.deferUpdate();
        return;
      }

      if (customId.startsWith('confirm_yes_') || customId.startsWith('confirm_no_')) {
        if (customId.startsWith('confirm_no_')) {
          await interaction.update({
            ...v2(musicContainer(`${E.cross} Cancelled`, 'Action cancelled.')),
            components: [],
            ...NO_PING
          });
          return;
        }
        await interaction.deferUpdate();
        return;
      }

      return;
    }

    if (interaction.isStringSelectMenu()) {
      if (interaction.customId === 'source_select') {
        const player = playerManager.getPlayer(client, interaction.guild?.id);
        if (!player) {
          return await interaction.reply({ ...v2(errorContainer('No active player.')), ...NO_PING, ephemeral: true });
        }
        const selected = interaction.values[0];
        player.currentSource = selected;
        await interaction.reply({
          ...v2(successContainer(`${E.source} Source changed to **${selected}**`)),
          ...NO_PING,
          ephemeral: true
        });
        return;
      }

      if (interaction.customId === 'help_category') {
        const selected = interaction.values[0];
        const response = await helpCommand.renderHelp(client, selected);
        await interaction.update({ ...response, ...NO_PING });
        return;
      }

      return;
    }

    if (interaction.isModalSubmit()) {
      await interaction.deferUpdate();
      return;
    }
  }
};
