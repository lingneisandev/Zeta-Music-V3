'use strict';

const { ActivityType, Events } = require('discord.js');
const { log } = require('../utils/logger');
const devLogger = require('../utils/devLogger');
const E = require('../emoji');

module.exports = {
  name: Events.ClientReady,
  once: true,
  execute: async (client) => {
    client.user.setPresence({
      activities: [{
        name: `${E.music} /play | !play | @mention play`,
        type: ActivityType.Listening
      }],
      status: 'online'
    });

    log.ready(`${E.online} ${client.user.tag} is online`);
    await devLogger.sendReady(client);
  }
};
