'use strict';

const {
  SlashCommandBuilder, ContainerBuilder, TextDisplayBuilder,
  SeparatorBuilder, SeparatorSpacingSize, ActionRowBuilder,
  StringSelectMenuBuilder, MediaGalleryBuilder, MediaGalleryItemBuilder,
  MessageFlags, AttachmentBuilder
} = require('discord.js');
const { COLORS } = require('../../utils/embedBuilder');
const { buildHelpBanner } = require('../../utils/canvasBuilder');
const E = require('../../emoji');

const CATEGORIES = {
  music: {
    emoji: E.music,
    label: 'Music',
    commands: [
      { name: 'play', usage: '/play <query> [source]', desc: 'Play a song or add to queue' },
      { name: 'skip', usage: '/skip [amount]', desc: 'Skip tracks' },
      { name: 'stop', usage: '/stop', desc: 'Stop and disconnect' },
      { name: 'queue', usage: '/queue [page]', desc: 'View the queue' },
      { name: 'nowplaying', usage: '/nowplaying', desc: 'Show current track' },
      { name: 'pause', usage: '/pause', desc: 'Pause playback' },
      { name: 'resume', usage: '/resume', desc: 'Resume playback' },
      { name: 'volume', usage: '/volume <1-100>', desc: 'Set volume' },
      { name: 'seek', usage: '/seek <time>', desc: 'Seek to position' },
      { name: 'loop', usage: '/loop <off|track|queue>', desc: 'Set loop mode' },
      { name: 'shuffle', usage: '/shuffle', desc: 'Shuffle the queue' },
      { name: 'remove', usage: '/remove <position>', desc: 'Remove a track' },
      { name: 'move', usage: '/move <from> <to>', desc: 'Move a track' },
      { name: 'lyrics', usage: '/lyrics [query]', desc: 'Get lyrics' },
      { name: 'autoplay', usage: '/autoplay', desc: 'Toggle autoplay (Premium)' },
      { name: 'source', usage: '/source [platform]', desc: 'Change source' },
      { name: 'filters', usage: '/filters <preset>', desc: 'Audio filters (Premium)' }
    ]
  },
  premium: {
    emoji: E.premium,
    label: 'Premium',
    commands: [
      { name: 'redeem', usage: '/redeem <key>', desc: 'Redeem a premium key' },
      { name: 'premiumstatus', usage: '/premiumstatus', desc: 'Check premium status' },
      { name: 'perks', usage: '/perks', desc: 'View premium perks' },
      { name: 'avatar', usage: '/avatar set/reset', desc: 'Custom bot avatar' },
      { name: 'banner', usage: '/banner set/reset', desc: 'Custom bot banner' }
    ]
  },
  config: {
    emoji: E.cmds,
    label: 'Config',
    commands: [
      { name: 'prefix', usage: '/prefix set/reset', desc: 'Set server prefix' },
      { name: 'dj', usage: '/dj set/remove', desc: 'Set DJ role' },
      { name: 'channel', usage: '/channel lock/unlock', desc: 'Lock music channel' },
      { name: 'language', usage: '/language set <lang>', desc: 'Set language' },
      { name: 'settings', usage: '/settings', desc: 'View server settings' }
    ]
  },
  info: {
    emoji: E.info,
    label: 'Info',
    commands: [
      { name: 'help', usage: '/help [category]', desc: 'Show this menu' },
      { name: 'ping', usage: '/ping', desc: 'Check latency' },
      { name: 'invite', usage: '/invite', desc: 'Get invite link' },
      { name: 'botinfo', usage: '/botinfo', desc: 'Bot information' },
      { name: 'serverinfo', usage: '/serverinfo', desc: 'Server information' }
    ]
  }
};

const renderHelp = async (client, category) => {
  const bannerBuffer = await buildHelpBanner();
  const bannerAttachment = new AttachmentBuilder(bannerBuffer, { name: 'help_banner.png' });

  const container = new ContainerBuilder()
    .setAccentColor(COLORS.info);

  container.addMediaGalleryComponents(
    new MediaGalleryBuilder().addItems(
      new MediaGalleryItemBuilder().setURL('attachment://help_banner.png')
    )
  );

  container.addSeparatorComponents(
    new SeparatorBuilder().setDivider(false).setSpacing(SeparatorSpacingSize.Small)
  );

  if (category && CATEGORIES[category]) {
    const cat = CATEGORIES[category];

    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`### ${cat.emoji} ${cat.label} Commands`)
    );
    container.addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    );

    let cmdText = '';
    for (const cmd of cat.commands) {
      cmdText += `**\`${cmd.name}\`** ${E.arrow} ${cmd.desc}\n\`${cmd.usage}\`\n\n`;
    }

    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(cmdText)
    );
    container.addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    );
  } else {
    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`### ${E.music} Command Categories`)
    );
    container.addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    );

    let overviewText = '';
    for (const [key, cat] of Object.entries(CATEGORIES)) {
      overviewText += `${cat.emoji} **${cat.label}** ${E.arrow} \`${cat.commands.length}\` commands\n`;
    }

    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(overviewText)
    );
    container.addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    );
  }

  const prefix = client.config.defaultPrefix || '!';
  container.addTextDisplayComponents(
    new TextDisplayBuilder().setContent(
      `${E.info} Select a category below or use \`/help <category>\`\n` +
      `${E.dot} Prefix: \`${prefix}\` ${E.dot} Mention: \`@${client.user.username}\``
    )
  );

  const selectRow = new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId('help_category')
      .setPlaceholder('Select a category')
      .addOptions(
        Object.entries(CATEGORIES).map(([key, cat]) => ({
          label: cat.label,
          value: key,
          description: `${cat.commands.length} commands`,
          default: category === key
        }))
      )
  );

  container.addActionRowComponents(selectRow);

  return { components: [container], files: [bannerAttachment], flags: MessageFlags.IsComponentsV2 };
};

module.exports = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('View all commands')
    .addStringOption((opt) => opt.setName('category').setDescription('Command category').setRequired(false)
      .addChoices(
        { name: 'Music', value: 'music' },
        { name: 'Premium', value: 'premium' },
        { name: 'Config', value: 'config' },
        { name: 'Info', value: 'info' }
      )),
  aliases: ['h'],
  premiumOnly: false,
  djOnly: false,
  cooldown: 3,
  execute: async (ctx) => {
    const category = ctx.isInteraction
      ? ctx.options.getString('category')
      : (ctx.args[0] || '').toLowerCase();

    const response = await renderHelp(ctx.client, category);
    await ctx.reply(response);
  },
  renderHelp
};
