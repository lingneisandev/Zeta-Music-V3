'use strict';

const {
  SlashCommandBuilder,
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  MessageFlags
} = require('discord.js');
const { COLORS } = require('../../utils/embedBuilder');

const NO_PING = { allowedMentions: { parse: [] } };

const latencyColor = (ms) => {
  if (ms < 100) return 0x2ecc71;
  if (ms < 200) return 0xf39c12;
  return 0xff3333;
};

const latencyLabel = (ms) => {
  if (ms < 100) return '`Excellent`';
  if (ms < 200) return '`Good`';
  return '`High`';
};

const bar = (ms) => {
  const total = 10;
  const filled = Math.min(Math.round((ms / 300) * total), total);
  return '█'.repeat(filled) + '░'.repeat(total - filled);
};

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ping')
    .setDescription('Check bot latency'),
  aliases: ['latency'],
  premiumOnly: false,
  djOnly: false,
  cooldown: 3,
  execute: async (ctx) => {
    const start = Date.now();

    const loading = new ContainerBuilder()
      .setAccentColor(COLORS.info)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent('### Pinging…')
      );

    const msg = await ctx.reply({
      components: [loading],
      flags: MessageFlags.IsComponentsV2,
      ...NO_PING
    });

    const rest = Date.now() - start;
    const ws = ctx.client.ws.ping;
    const worst = Math.max(rest, ws);

    const result = new ContainerBuilder()
      .setAccentColor(latencyColor(worst));

    result.addTextDisplayComponents(
      new TextDisplayBuilder().setContent('### Pong!')
    );
    result.addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    );
    result.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `**WebSocket**\n\`${bar(ws)}\`  \`${ws}ms\`  ${latencyLabel(ws)}\n\n` +
        `**REST API**\n\`${bar(rest)}\`  \`${rest}ms\`  ${latencyLabel(rest)}`
      )
    );

    const payload = { components: [result], flags: MessageFlags.IsComponentsV2, ...NO_PING };

    if (ctx.isInteraction) {
      await ctx.raw.editReply(payload);
    } else {
      await msg.edit(payload);
    }
  }
};
