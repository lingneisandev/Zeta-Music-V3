'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { successContainer, v2 } = require('../../utils/embedBuilder');
const { log } = require('../../utils/logger');
const { sleep } = require('../../utils/logger');
const E = require('../../emoji');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('shutdown')
    .setDescription('Gracefully shut down the bot'),
  aliases: [],
  premiumOnly: false,
  ownerOnly: true,
  djOnly: false,
  cooldown: 0,
  execute: async (ctx) => {
    await ctx.reply({
      ...v2(successContainer(`${E.shutdown} Shutting down...`)),
      ephemeral: true
    });

    log.warn(`${E.shutdown} Shutdown initiated by ${ctx.user.tag}`);

    await sleep(2000);
    ctx.client.destroy();
    process.exit(0);
  }
};
